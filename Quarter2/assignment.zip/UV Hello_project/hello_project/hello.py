def main():
    print("Hello from Sufyan!")


if __name__ == "__main__":
    main()
